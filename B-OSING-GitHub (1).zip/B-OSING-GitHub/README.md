# B-OSING Flood Alert

Proyek pemantauan risiko banjir berbasis ESP32 dengan sensor ultrasonik, sensor hujan, sensor luapan, indikator LED, buzzer, LCD I2C, dan notifikasi Telegram.

## Isi repository
- `B-OSING.ino` — kode Arduino untuk ESP32.
- `README.md` — panduan setup dasar.

## Penting sebelum digunakan
1. **Jangan pernah mengunggah token bot Telegram atau password Wi-Fi asli ke repository publik.** Kode di repository ini memakai placeholder.
2. Token Telegram yang pernah dimasukkan ke file/chat harus dianggap sudah terekspos. Buka **@BotFather** di Telegram, gunakan `/revoke` untuk bot tersebut, lalu buat/gunakan token baru. Jangan tempel token baru ke GitHub publik.
3. Isi placeholder di `B-OSING.ino` hanya pada salinan lokal: `ISI_NAMA_WIFI_DI_SINI`, `ISI_PASSWORD_WIFI_DI_SINI`, `ISI_TOKEN_BOT_BARU_DI_SINI`, dan `ISI_CHAT_ID_DI_SINI`.
4. Kode awal punya konflik pin untuk sensor luapan dan buzzer. Salinan ini memindahkan buzzer ke GPIO23; sesuaikan kabel buzzer agar cocok. Pastikan GPIO23 tidak dipakai perangkat lain.
5. Periksa kembali seluruh pin dan tegangan sensor sebelum menyalakan perangkat. Pin `PIN_ECHO` ESP32 tidak boleh menerima sinyal 5 V secara langsung.
6. `PAKAI_SERTIFIKAT` diset ke `0` agar memakai `klien.setInsecure()` pada salinan ini. Ini lebih mudah untuk uji awal tetapi tidak memverifikasi sertifikat server; untuk penggunaan nyata, lebih baik gunakan sertifikat CA Telegram.
7. Kode ini belum dikompilasi atau diuji pada perangkat keras. Uji dan perbaiki error kompilasi/library sebelum dipakai sebagai sistem peringatan banjir sungguhan.

## Library Arduino yang diperlukan
Pasang melalui Library Manager Arduino IDE:
- LiquidCrystal I2C
- UniversalTelegramBot
- ArduinoJson

Gunakan board ESP32 yang sesuai di Arduino IDE.

## Cara upload ke GitHub
1. Buka https://github.com/new
2. Repository name: `B-OSING-Flood-Alert`
3. Pilih Public jika ingin dibagikan, atau Private jika hanya untuk sendiri/tim.
4. Klik **Create repository**.
5. Ekstrak ZIP ini, lalu pada halaman repository pilih **Add file → Upload files**.
6. Upload `B-OSING.ino` dan `README.md`, lalu klik **Commit changes**.
7. Link repository akan berbentuk `https://github.com/USERNAME/B-OSING-Flood-Alert` (ganti `USERNAME` dengan username GitHub kamu).

## Catatan keselamatan
B-OSING adalah prototipe edukasi dan bukan pengganti sistem peringatan resmi. Jangan mengandalkan prototipe ini sebagai satu-satunya dasar keputusan evakuasi.
