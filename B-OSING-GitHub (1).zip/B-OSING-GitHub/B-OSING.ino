#include <Stepper.h>
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <UniversalTelegramBot.h>
#include <ArduinoJson.h>
#include <time.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

const char* WIFI_SSID  = "ISI_NAMA_WIFI_DI_SINI";
const char* WIFI_PASS  = "ISI_PASSWORD_WIFI_DI_SINI";
#define BOT_TOKEN        "ISI_TOKEN_BOT_BARU_DI_SINI"
const char* CHAT_ID    = "ISI_CHAT_ID_DI_SINI";            
const char* NAMA_NODE  = "B-OSING-01";
const char* LOKASI     = "SUTRI";

#define PIN_TRIG        12   
#define PIN_ECHO        14   
#define PIN_HUJAN       34  
#define PIN_LUAPAN      32   
#define PIN_LUAPAN_PWR  27   
#define LED_HIJAU       25
#define LED_KUNING      26
#define LED_MERAH       33
#define PIN_BUZZER      23  // Pastikan GPIO23 tersedia dan buzzer dipindah ke pin ini   
// LCD I2C: SDA = GPIO21, SCL = GPIO22, alamat 0x27 
#define LCD_ALAMAT      0x27


const float JARAK_BAHAYA_CM  = 100.0;  // < 1 m   -> skor 3 (tidak aman)
const float JARAK_WASPADA_CM = 250.0;  // < 2,5 m -> skor 2 (waspada)
const float JARAK_DASAR_CM   = 400.0;  // 4 m = dasar sungai (>= 2,5 m = skor 1 aman)

const int HUJAN_ADC_TIDAK_ADA = 3000;  // >= 3000        -> tidak hujan/ringan (skor 1)
const int HUJAN_ADC_SEDANG    = 1800;  // 1800 - 2999    -> sedang (skor 2)


const int LUAPAN_ADC_AMBANG        = 600;    
const unsigned long LUAPAN_KONFIRM_MS = 5000; 
const unsigned long LUAPAN_BEBAS_MS   = 10000;
const unsigned long LUAPAN_JEDA_BACA  = 250;  

const float SUHU_UDARA_C = 28.0;               
const float CM_PER_US    = (331.3 + 0.606 * SUHU_UDARA_C) / 10000.0; 
const float JARAK_MIN_VALID = 25.0;            
const float JARAK_MAX_VALID = 450.0;
const int   JUMLAH_SAMPEL   = 9;             
const unsigned long JEDA_PING_MS = 60;
const unsigned long SIKLUS_MS    = 1000;       
const int KONFIRMASI_NAIK  = 3;                
const int KONFIRMASI_TURUN = 10;             
const int BATAS_ERROR_SENSOR = 10;             


const float LAJU_MIN_CM_MENIT   = 0.2;        
const float AMBANG_PREDIKSI_MNT = 30.0;        


const unsigned long INTERVAL_TG_MS[3] = { 30000UL, 15000UL, 10000UL }; 
const unsigned long TG_JEDA_MIN_MS    = 2000;  
const unsigned long TG_POLL_MS        = 3000;  
#define PAKAI_SERTIFIKAT 0



enum Status { AMAN = 0, WASPADA = 1, BAHAYA = 2 };

struct Snapshot {           
  bool  valid;
  int   status;
  int   frs;                 
  int   ta, ch, la;
  float jarak;               
  int   adcHujan;
  bool  luapan;
  float tLuap;               
  bool  sensorError;
};
Snapshot snap = {};
SemaphoreHandle_t snapMutex;

LiquidCrystal_I2C lcd(LCD_ALAMAT, 16, 2);

//  snesor ultrasonik
float sampel[JUMLAH_SAMPEL];
int   pingIdx = 0;
unsigned long lastPing = 0, cycleStart = 0;
float maBuf[5]; int maN = 0, maHead = 0;
float jarakFilter = -1;
bool  punyaJarak = false, sensorError = false;
int   errCount = 0, lastTA = 1;

// sensor hujan 
int hujanBuf[60]; int hujanN = 0, hujanHead = 0;

// sensor luapan
bool luapanAktif = false, luapanSedangBasah = false;
unsigned long luapanMulaiBasah = 0, luapanTerakhirBasah = 0, luapanTerakhirBaca = 0;
int luapanADC = 0;

// riwayat prediksi
struct Titik { double menit; float cm; };
Titik riw[60]; int riwN = 0, riwHead = 0;
unsigned long lastRiwayat = 0;
float tLuap = -1;

// status
int statusAktif = AMAN, hitungNaik = 0, hitungTurun = 0;
int skorTA = 1, skorCH = 1, skorLA = 1, frsPersen = 33, adcRataHujan = 4095;

// aktuator
unsigned long lastBuzzer = 0, lastBacklight = 0;
bool buzzerOn = false, backlightOn = true;



const char* namaStatus(int s) {
  return s == AMAN ? "AMAN" : (s == WASPADA ? "WASPADA" : "BAHAYA - EVAKUASI");
}
const char* namaHujan(int skor) {
  return skor == 1 ? "Tidak hujan/ringan" : (skor == 2 ? "Sedang" : "Lebat");
}
char kodeHujan(int skor) { return skor == 1 ? 'T' : (skor == 2 ? 'S' : 'L'); }

void lcdBaris(int baris, const char* teks) {
  char b[17];
  snprintf(b, sizeof(b), "%-16s", teks);   
  lcd.setCursor(0, baris);
  lcd.print(b);
}

void setLED(int s) {
  digitalWrite(LED_HIJAU,  s == AMAN);
  digitalWrite(LED_KUNING, s == WASPADA);
  digitalWrite(LED_MERAH,  s == BAHAYA);
}


// 4a Ultrasonik JSN-SR04T 
float satuPing() {
  digitalWrite(PIN_TRIG, LOW);  delayMicroseconds(4);
  digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(12);
  digitalWrite(PIN_TRIG, LOW);
  unsigned long t = pulseIn(PIN_ECHO, HIGH, 30000UL);
  if (t == 0) return -1;
  float cm = t * CM_PER_US / 2.0;
  if (cm < JARAK_MIN_VALID || cm > JARAK_MAX_VALID) return -1;
  return cm;
}

// dipanggil dari loop(): 1 ping tiap 60 ms, 9 ping = 1 pengukuran (non-blocking)
bool pingUpdate() {
  unsigned long now = millis();
  if (pingIdx == 0 && now - cycleStart < SIKLUS_MS) return false;
  if (now - lastPing < JEDA_PING_MS) return false;
  if (pingIdx == 0) cycleStart = now;
  lastPing = now;
  sampel[pingIdx++] = satuPing();
  if (pingIdx < JUMLAH_SAMPEL) return false;
  pingIdx = 0;

  // median filter
  float v[JUMLAH_SAMPEL]; int n = 0;
  for (int i = 0; i < JUMLAH_SAMPEL; i++) if (sampel[i] > 0) v[n++] = sampel[i];
  if (n >= 5) {
    for (int i = 1; i < n; i++) { float k = v[i]; int j = i - 1;
      while (j >= 0 && v[j] > k) { v[j + 1] = v[j]; j--; } v[j + 1] = k; }
    float med = v[n / 2];
    // moving average 5 data
    maBuf[maHead] = med; maHead = (maHead + 1) % 5; if (maN < 5) maN++;
    float s = 0; for (int i = 0; i < maN; i++) s += maBuf[i];
    jarakFilter = s / maN;
    punyaJarak = true; errCount = 0; sensorError = false;
  } else {
    errCount++;
    if (errCount >= BATAS_ERROR_SENSOR) sensorError = true;
  }
  return true;   // satu siklus pengukuran selesai
}

// 4b. Sensor hujan
int bacaHujanRata() {
  long s = 0;
  for (int i = 0; i < 16; i++) s += analogRead(PIN_HUJAN);
  int adc = s / 16;
  hujanBuf[hujanHead] = adc; hujanHead = (hujanHead + 1) % 60; if (hujanN < 60) hujanN++;
  long t = 0; for (int i = 0; i < hujanN; i++) t += hujanBuf[i];
  return t / hujanN;
}

// 4c. Sensor luapan air
void luapanUpdate() {
  unsigned long now = millis();
  if (now - luapanTerakhirBaca < LUAPAN_JEDA_BACA) return;
  luapanTerakhirBaca = now;
  digitalWrite(PIN_LUAPAN_PWR, HIGH); delay(5);         
  luapanADC = analogRead(PIN_LUAPAN);
  digitalWrite(PIN_LUAPAN_PWR, LOW);

  if (luapanADC >= LUAPAN_ADC_AMBANG) {            
    if (!luapanSedangBasah) { luapanSedangBasah = true; luapanMulaiBasah = now; }
    luapanTerakhirBasah = now;
    if (!luapanAktif && now - luapanMulaiBasah >= LUAPAN_KONFIRM_MS) luapanAktif = true;
  } else {                                               
    luapanSedangBasah = false;
    if (luapanAktif && now - luapanTerakhirBasah >= LUAPAN_BEBAS_MS) luapanAktif = false;
  }
}



int skorTinggi(float cm) { return cm < JARAK_BAHAYA_CM ? 3 : (cm < JARAK_WASPADA_CM ? 2 : 1); }
int skorHujan(int adc)   { return adc >= HUJAN_ADC_TIDAK_ADA ? 1 : (adc >= HUJAN_ADC_SEDANG ? 2 : 3); }

// prediksi:
float hitungPrediksi(float jarakNow) {
  if (riwN < 6) return -1;
  double tNow = riw[(riwHead - 1 + 60) % 60].menit;
  double sx = 0, sy = 0, sxx = 0, sxy = 0;
  for (int i = 0; i < riwN; i++) {
    double x = riw[i].menit - tNow, y = riw[i].cm;
    sx += x; sy += y; sxx += x * x; sxy += x * y;
  }
  double den = riwN * sxx - sx * sx;
  if (fabs(den) < 1e-9) return -1;
  double slope = (riwN * sxy - sx * sy) / den;           
  float laju = -slope;                                   
  if (laju < LAJU_MIN_CM_MENIT) return -1;
  float sisa = jarakNow - JARAK_BAHAYA_CM;
  if (sisa <= 0) return 0;
  return sisa / laju;
}

int klasifikasi(int ta, int ch, int la, float tl) {
  int total = ta + ch + la;                              
  int st = (total <= 4) ? AMAN : (total <= 6) ? WASPADA : BAHAYA;
  if (la == 3) st = BAHAYA;                            
  else if ((ta >= 2 || ch >= 2) && st == AMAN) st = WASPADA;  
  if (tl >= 0 && tl < AMBANG_PREDIKSI_MNT && st == AMAN) st = WASPADA; 
  return st;
}

void konfirmasi(int calon, bool langsung) {
  if (langsung) { statusAktif = calon; hitungNaik = hitungTurun = 0; return; }
  if (calon > statusAktif) {
    hitungTurun = 0;
    if (++hitungNaik >= KONFIRMASI_NAIK) { statusAktif = calon; hitungNaik = 0; }
  } else if (calon < statusAktif) {
    hitungNaik = 0;
    if (++hitungTurun >= KONFIRMASI_TURUN) { statusAktif = calon; hitungTurun = 0; }
  } else { hitungNaik = hitungTurun = 0; }
}



void tampilkanLCD() {
  char b1[24], b2[24], jt[8];
  if (statusAktif == BAHAYA) strcpy(b1, "!!! EVAKUASI !!!");
  else snprintf(b1, sizeof(b1), "%-7s FRS:%3d%%", statusAktif == AMAN ? "AMAN" : "WASPADA", frsPersen);
  if (sensorError || !punyaJarak) strcpy(jt, "ERR  ");
  else snprintf(jt, sizeof(jt), "%3dcm", (int)jarakFilter);
  snprintf(b2, sizeof(b2), "J:%s H:%c L:%s", jt, kodeHujan(skorCH), luapanAktif ? "!!" : "--");
  lcdBaris(0, b1);
  lcdBaris(1, b2);
}

void aktuatorUpdate() {          
  unsigned long now = millis();
  if (statusAktif == BAHAYA) {
    if (now - lastBuzzer >= 300) { lastBuzzer = now; buzzerOn = !buzzerOn; digitalWrite(PIN_BUZZER, buzzerOn); }
    if (now - lastBacklight >= 500) {
      lastBacklight = now; backlightOn = !backlightOn;
      backlightOn ? lcd.backlight() : lcd.noBacklight();
    }
  } else {
    if (buzzerOn) { buzzerOn = false; digitalWrite(PIN_BUZZER, LOW); }
    if (!backlightOn) { backlightOn = true; lcd.backlight(); }
  }
}


void evaluasi() {
  if (!punyaJarak && !sensorError) return;              

  int ta;
  if (!sensorError) { ta = skorTinggi(jarakFilter); lastTA = ta; }
  else ta = max(lastTA, 2);                              

  adcRataHujan = bacaHujanRata();
  int ch = skorHujan(adcRataHujan);
  int la = luapanAktif ? 3 : 1;

  if (punyaJarak && !sensorError && millis() - lastRiwayat >= 10000UL) {  
    lastRiwayat = millis();
    riw[riwHead] = { millis() / 60000.0, jarakFilter };
    riwHead = (riwHead + 1) % 60; if (riwN < 60) riwN++;
  }
  tLuap = (punyaJarak && !sensorError) ? hitungPrediksi(jarakFilter) : -1;

  int total = ta + ch + la;
  frsPersen = (int)round(total / 9.0 * 100.0);
  skorTA = ta; skorCH = ch; skorLA = la;

  int calon = klasifikasi(ta, ch, la, tLuap);
  konfirmasi(calon, la == 3);                           

  setLED(statusAktif);
  tampilkanLCD();

  xSemaphoreTake(snapMutex, portMAX_DELAY);
  snap.valid = true; snap.status = statusAktif; snap.frs = frsPersen;
  snap.ta = ta; snap.ch = ch; snap.la = la;
  snap.jarak = punyaJarak ? jarakFilter : -1; snap.adcHujan = adcRataHujan;
  snap.luapan = luapanAktif; snap.tLuap = tLuap; snap.sensorError = sensorError;
  xSemaphoreGive(snapMutex);

  Serial.printf("[%lus] J=%.1fcm TA=%d | ADC hujan=%d CH=%d | luapan ADC=%d LA=%d | FRS=%d%% -> %s | tLuap=%.1f\n",
                millis() / 1000, jarakFilter, ta, adcRataHujan, ch, luapanADC, la,
                frsPersen, namaStatus(statusAktif), tLuap);
}


WiFiClientSecure klien;
UniversalTelegramBot bot(BOT_TOKEN, klien);

Snapshot ambilSnap() {
  Snapshot c;
  xSemaphoreTake(snapMutex, portMAX_DELAY);
  c = snap;
  xSemaphoreGive(snapMutex);
  return c;
}

String waktuStr() {
  struct tm t;
  if (!getLocalTime(&t, 50)) return "-";
  char b[24];
  strftime(b, sizeof(b), "%d/%m/%Y %H:%M:%S", &t);
  return String(b);
}

String buatLaporan(const Snapshot& s, const String& judul) {
  const char* ikon = s.status == AMAN ? "🟢" : (s.status == WASPADA ? "🟡" : "🔴");
  String m = String(ikon) + " " + judul + "\n";
  m += "Node   : " + String(NAMA_NODE) + "\n";
  m += "Lokasi : " + String(LOKASI) + "\n";
  m += "Waktu  : " + waktuStr() + "\n\n";
  m += "STATUS : " + String(namaStatus(s.status)) + "\n";
  m += "FRS    : " + String(s.frs) + "% (skor TA/CH/LA = " + s.ta + "/" + s.ch + "/" + s.la + ")\n\n";
  if (s.jarak > 0) m += "Jarak sensor ke air : " + String(s.jarak, 1) + " cm\n";
  else             m += "Jarak sensor ke air : tidak terbaca\n";
  m += "Hujan  : " + String(namaHujan(s.ch)) + " (ADC " + s.adcHujan + ")\n";
  m += "Luapan : " + String(s.luapan ? "AIR MENYENTUH SENSOR (MELUAP)" : "Normal") + "\n";
  if (s.tLuap >= 0 && s.tLuap < 999) m += "Prediksi batas bahaya : +/- " + String(s.tLuap, 0) + " menit\n";
  else                               m += "Prediksi batas bahaya : tidak ada tren naik\n";
  if (s.sensorError) m += "\n⚠️ Sensor ketinggian ERROR (mode fail-safe)\n";
  if (s.status == BAHAYA) m += "\n🚨 SEGERA EVAKUASI KE TEMPAT AMAN!";
  return m;
}

void taskTelegram(void*) {
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
#if PAKAI_SERTIFIKAT
  klien.setCACert(TELEGRAM_CERTIFICATE_ROOT);
#else
  klien.setInsecure();
#endif
  unsigned long lastWifi = 0, lastSend = 0, lastPoll = 0, lastTry = 0;
  int lastStatusSent = -1; bool lastErrSent = false, ntpMulai = false;

  for (;;) {
    // --- Wi-Fi (alarm lokal tetap jalan walau internet putus) ---
    if (WiFi.status() != WL_CONNECTED) {
      if (lastWifi == 0 || millis() - lastWifi > 15000UL) {
        WiFi.disconnect(); WiFi.begin(WIFI_SSID, WIFI_PASS); lastWifi = millis();
      }
      vTaskDelay(pdMS_TO_TICKS(500)); continue;
    }
    // --- sinkron waktu (WIB = UTC+7) ---
    if (!ntpMulai) { configTime(7 * 3600, 0, "pool.ntp.org", "time.google.com"); ntpMulai = true; }
#if PAKAI_SERTIFIKAT
    if (time(nullptr) < 1700000000) { vTaskDelay(pdMS_TO_TICKS(500)); continue; }
#endif
    Snapshot s = ambilSnap();
    if (!s.valid) { vTaskDelay(pdMS_TO_TICKS(500)); continue; }
    unsigned long now = millis();

    // --- 1) kirim saat status berubah / sensor error berubah ---
    bool bolehKirim = (now - lastSend >= TG_JEDA_MIN_MS) && (now - lastTry >= 5000UL || lastTry == 0);
    if (bolehKirim && (s.status != lastStatusSent || s.sensorError != lastErrSent)) {
      lastTry = now;
      String judul;
      if (lastStatusSent < 0)              judul = "B-OSING AKTIF - laporan awal";
      else if (s.status != lastStatusSent) judul = String("PERUBAHAN STATUS: ") + namaStatus(lastStatusSent) + " -> " + namaStatus(s.status);
      else                                 judul = s.sensorError ? "PERINGATAN: sensor ketinggian error" : "Sensor ketinggian pulih";
      if (bot.sendMessage(CHAT_ID, buatLaporan(s, judul), "")) {
        lastStatusSent = s.status; lastErrSent = s.sensorError; lastSend = millis();
      }
    }
    // --- 2) laporan berkala (real-time) sesuai interval status ---
    else if (bolehKirim && INTERVAL_TG_MS[s.status] > 0 && now - lastSend >= INTERVAL_TG_MS[s.status]) {
      lastTry = now;
      if (bot.sendMessage(CHAT_ID, buatLaporan(s, "Laporan berkala"), "")) lastSend = millis();
    }

    // --- 3) perintah dari Telegram: /status  /help ---
    if (now - lastPoll >= TG_POLL_MS) {
      lastPoll = now;
      int n = bot.getUpdates(bot.last_message_received + 1);
      while (n) {
        for (int i = 0; i < n; i++) {
          String cid = bot.messages[i].chat_id, teks = bot.messages[i].text;
          if (cid != String(CHAT_ID)) { bot.sendMessage(cid, "Anda tidak terdaftar sebagai penerima B-OSING.", ""); continue; }
          if (teks.startsWith("/status")) {
            bot.sendMessage(CHAT_ID, buatLaporan(ambilSnap(), "Status saat ini (permintaan manual)"), "");
            lastSend = millis();
          } else {
            bot.sendMessage(CHAT_ID, "B-OSING - perintah:\n/status = data sensor sekarang\n"
                                     "Peringatan dikirim otomatis saat status berubah.", "");
          }
        }
        n = bot.getUpdates(bot.last_message_received + 1);
      }
    }
    vTaskDelay(pdMS_TO_TICKS(200));
  }
}



void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT); pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_LUAPAN_PWR, OUTPUT); digitalWrite(PIN_LUAPAN_PWR, LOW);
  pinMode(LED_HIJAU, OUTPUT); pinMode(LED_KUNING, OUTPUT); pinMode(LED_MERAH, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT); digitalWrite(PIN_BUZZER, LOW);
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_HUJAN, ADC_11db);
  analogSetPinAttenuation(PIN_LUAPAN, ADC_11db);

  Wire.begin(21, 22);
  lcd.init(); lcd.backlight();
  lcdBaris(0, "B-OSING  v1.0"); lcdBaris(1, "Memulai sistem..");

  // uji LED & buzzer saat menyala
  digitalWrite(LED_HIJAU, HIGH); digitalWrite(LED_KUNING, HIGH); digitalWrite(LED_MERAH, HIGH);
  digitalWrite(PIN_BUZZER, HIGH); delay(200); digitalWrite(PIN_BUZZER, LOW);
  delay(600); setLED(-1);

  snapMutex = xSemaphoreCreateMutex();
  xTaskCreatePinnedToCore(taskTelegram, "telegram", 12288, NULL, 1, NULL, 0);
  lcdBaris(1, "Mengukur...");
}

void loop() {
  luapanUpdate();                    // pantau sensor luapan (debounce 5 detik)
  if (pingUpdate()) evaluasi();      // 9 ping selesai -> hitung FRS, LED, LCD
  aktuatorUpdate();                  // buzzer & kedip layar saat BAHAYA
}
